import cv2
import tkinter as tk
from PIL import Image, ImageTk
from threading import Thread
from VideoStream import VideoStream

class Application:
    def __init__(self, root, stream_url):
        self.root = root
        self.stream = VideoStream(stream_url)
        self.setup_ui()

    def setup_ui(self):
        self.root.title("ESP32 Camera Stream")
        self.root.geometry("400x300")

        self.lbl_video = tk.Label(self.root)
        self.lbl_video.pack()

        control_panel = tk.Frame(self.root)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X)

        btn_start = tk.Button(control_panel, text="Iniciar", command=self.start_video)
        btn_start.pack(side=tk.LEFT)

        btn_stop = tk.Button(control_panel, text="Parar", command=self.stop_video)
        btn_stop.pack(side=tk.LEFT)

        # Manejar el cierre de la ventana
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def start_video(self):
        self.stream.start_stream()
        self.update_ui()

    def stop_video(self):
        self.stream.stop_stream()

    def update_ui(self):
        if self.stream.streaming and self.stream.frame is not None:
            img = Image.fromarray(self.stream.frame)
            imgtk = ImageTk.PhotoImage(image=img)
            self.lbl_video.imgtk = imgtk
            self.lbl_video.configure(image=imgtk)
        if self.stream.streaming:
            self.root.after(10, self.update_ui)

    def on_close(self):
        # Detener el stream de video
        self.stream.stop_stream()

        # Cerrar la ventana
        self.root.destroy()


# URL del stream de video
stream_url = 'http://*************/stream'

# Inicia la aplicación
root = tk.Tk()
app = Application(root, stream_url)
root.mainloop()