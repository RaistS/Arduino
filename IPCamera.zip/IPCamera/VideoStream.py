import cv2
import tkinter as tk
from PIL import Image, ImageTk
from threading import Thread

class VideoStream:
    def __init__(self, url, resolution=(320, 240)):
        self.url = url
        self.cap = None
        self.streaming = False
        self.frame = None
        self.resolution = resolution

    def start_stream(self):
        self.streaming = True
        self.cap = cv2.VideoCapture(self.url)
        self.thread = Thread(target=self.update_frame)
        self.thread.daemon = True
        self.thread.start()

    def stop_stream(self):
        self.streaming = False
        if self.cap:
            self.cap.release()
        self.cap = None

    def update_frame(self):
        while self.streaming:
            ret, frame = self.cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                self.frame = cv2.resize(frame, self.resolution)
            else:
                break