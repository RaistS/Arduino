import tkinter as tk
from tkinter import font as tkFont
import socket
import threading

class Interfaz:
    def __init__(self, root):
        self.root = root
        self.root.title("Interfaz")
        self.root.geometry('528x578')

        # Etiqueta para "Mano Dcha."
        self.lblManoDcha = tk.Label(root, text="Mano Dcha.", font=tkFont.Font(family="Tahoma", size=16, weight="bold"))
        self.lblManoDcha.place(x=30, y=360)

        # Etiqueta para mostrar los datos de "Mano Dcha."
        self.datoManoDcha = tk.Label(root, text="Dato Mano Derecha", fg="red", font=tkFont.Font(family="Tahoma", size=16))
        self.datoManoDcha.place(x=30, y=390, width=350, height=25)

        # Etiqueta para la imagen
        self.lblNewLabel_1 = tk.Label(root)
        self.lblNewLabel_1.place(x=100, y=0, width=350, height=350)
        self.load_image()

        # Inicia el servidor UDP en un hilo separado
        self.start_udp_server()

    def load_image(self):
        # Carga la imagen.
        self.image = tk.PhotoImage(file="Imagen1.png")
        self.lblNewLabel_1.config(image=self.image)

    def update_data(self, data):
        # Actualiza la etiqueta con los datos recibidos
        self.datoManoDcha.config(text=data)

    def udp_server_thread(self):
        # Crea un socket UDP
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_address = ('', 4210)
        sock.bind(server_address)

        while True:
            data, address = sock.recvfrom(4096)
            data = data.decode('utf-8')
            # Actualiza la interfaz gráfica con los datos recibidos
            self.root.after(0, self.update_data, data)

    def start_udp_server(self):
        # Inicia el hilo del servidor UDP
        threading.Thread(target=self.udp_server_thread, daemon=True).start()

# Crea la ventana principal y lanza la aplicación
root = tk.Tk()
app = Interfaz(root)
root.mainloop()
